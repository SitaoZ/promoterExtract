# Overview

The ngs-tools is python package for bioinformatics. 
Package format is a bioinformatics file format. 
Package util is a common tools software. 
Package PopGen is a population genetics software. 
Package pipe is a pipeline of frequently-used.

## Brief introduction of format package

1. **Install** <br>
    ```bash
    tar -zxvf Python-3.6.1.tgz
    cd Python-3.6.1
    ./configure
    make && make install
    git clone https://github.com/zhusitao1990/ngs-tools.git
    ```
