from promoterExtract import get_prom


def main():
    get_prom()


if __name__ == "__main__":
    main()
